# Env. Setup

## Developing inside a Container

https://code.visualstudio.com/docs/remote/containers

## Enable Linting on Save with Visual Studio Code and ESLint

https://dev.to/alexcoding42/set-up-typescript-eslint-husky-and-lint-staged-in-a-next-js-11-project-5g5j  
https://paulintrognon.fr/blog/typescript-prettier-eslint-next-js  
https://www.digitalocean.com/community/tutorials/workflow-auto-eslinting

#### .vscode/settings.json

```json
{
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": true
  },
  "eslint.validate": ["javascript"]
}
```

## VSCode Plugins

### Types auto installer

https://marketplace.visualstudio.com/items?itemName=jvitor83.types-autoinstaller

```md
Press Ctrl+P and narrow down the list commands by typing `ext install types-autoinstaller`.
```

## Registry Proxy

```
yarn config set registry http://nexus..
yarn config set metrics-registry http://nexus..
npm set registry http://nexus..
npm set metrics-registry http://nexus..
```

## Comments in package.json

```json
{
  "scripts": {
    "about": "echo 'Say something about this project'",

    "about:build": "echo 'Say something about building it'",
    "build": "do something",

    "about:watch": "echo 'Say something about how watch works'",
    "watch": "do something"
  },

  "comments": {
    "dependencies": "We use Bootstrap 5, we will upgrade to v5 once is ready for production"
  }
}
```

<br/>

# Packages Candidates

### \* DB

`yarn add mongodb-memory-server`  
`yarn add -D @types/mongodb-memory-server`

`npm i mongodb-memory-server`  
`npm i -D @types/mongodb-memory-server`

(https://dev.to/paulasantamaria/testing-node-js-mongoose-with-an-in-memory-database-32np)

--  
sqlite3 (https://github.com/mapbox/node-sqlite3)  
DATABASE_URL=sqlite://localhost/:memory:?synchronize=true

--  
lowdb
https://github.com/typicode/lowdb

--

Prisma (vs. TypeORM)  
 https://www.prisma.io/docs/concepts/more/comparisons/prisma-and-typeorm

### \* Send REST request

`yarn add axios`  
(has its own type definitions)

### \* CORS

`yarn add cors`  
`yarn add -D @types/cors`

(also see https://nextjs.org/docs/api-routes/api-middlewares)

### \* Data model

`yarn add mongoose`  
(has its own type definitions)

### \* Data mock

### \* Data manipulation

`yarn add lodash`  
`yarn add -D @types/lodash`

### \* Log manage

`yarn add log4js`  
(has its own type definitions)

`yarn add morgan`  
`yarn add -D @types/morgan`

### \* json r/w with comments suppot

`yarn add comment-json`  
(has its own type definitions)

### \* Unit test - jest

`yarn add -D jest ts-jest @types/jest`

<br/>

# Reference

### # npm trends

https://www.npmtrends.com/mockingoose-vs-mongo-unit-vs-mongodb-memory-server-vs-mongoose-mock

### # Others

https://pouchdb.com/  
https://github.com/Azure/autorest

https://github.com/swagger-api/swagger-codegen  
https://developer.atlassian.com/cloud/jira/platform/swagger.json  
https://developer.atlassian.com/cloud/jira/platform/swagger-v3.v3.json

VSCode + ESLint + Prettier + TypeScript setup  
https://glebbahmutov.com/blog/configure-prettier-in-vscode/

### # ToRead

- [Complete setup of Nextjs, SWR , Axios and Material UI with SSR for your upcomming projects
  ](https://dev.to/harshmangalam/complete-setup-of-nextjs-swr-axios-and-material-ui-with-ssr-for-your-upcomming-projects-25b0)

#### MongoDB/axios/Prisma

- [How To Build a Todo App with React, TypeScript, NodeJS, and MongoDB](https://www.ibrahima-ndaw.com/blog/how-to-buil-a-todo-app-with-react-and-node-js/)
- [Using WordPress as a Headless CMS with React/Next.js (axios)](https://medium.com/geekculture/using-wordpress-as-a-headless-cms-with-react-next-js-c9b97bfc9ce2)
- [Create a Fullstack Blog App with Next.js, Prisma 2 and Docker](https://www.youtube.com/playlist?list=PLNVtwe5rhabD2xESqtOC8dHeCARSlvnfJ)  
  (https://www.codemochi.com/blog/2019-07-08-prisma-2-nextjs-docker)

#### Tailwind CSS

- [tailwindcss](https://tailwindcss.com/)
- [Next.js + Tailwind CSS Example](https://github.com/vercel/next.js/tree/canary/examples/with-tailwindcss)

#### Strapi

- [How to build a To-do App using Next.js and Strapi](https://strapi.io/blog/how-to-build-a-to-do-app-using-next-js-and-strapi)  
  (https://github.com/strapi/strapi)
- [Strapi template Next example](https://github.com/vercel/next.js/tree/canary/examples/cms-strapi)

# debug example

```js
let theme = props.theme;

// Basic usage
console.log("theme", theme);

// Indented JSON output with 2 spaces
console.log("theme", JSON.stringify(theme, undefined, 2));

// Human-readable output with colors
console.log("theme", require("util").inspect(theme, { colors: true }));
```

(https://dev.to/spe_/debugging-next-js-applications-46b6)

# Auth

refer: https://nextjs.org/docs/authentication

## next-auth

https://medium.com/technest/next-js-oauth-with-nextauth-js-53a9f2b9994f  
https://next-auth.js.org/configuration/providers  
https://github.com/nextauthjs/next-auth

# ToDo

- [ ] CSS support (build-in CSS, TailwindCSS)
- [ ] API definition (.gql)
- [ ] Study apollo
- [ ] docker-composer devcontainer with Mariadb/PrismaPlayground/YogaGraphQL
- [ ] with-apollo App (with Redux?)
- [ ] Test tool 'insomnia' - like postman, support REST/swagger/GraphQL
