module.exports = {
    env: {
        browser: true,
        node: true,
        es6: true,
    },
    //extends: ["eslint:recommended", "plugin:prettier/recommended"],
    // parserOptions: {
    //     ecmaVersion: 12,
    //     sourceType: "module",
    // },
    extends: [
        "next/core-web-vitals",
        "plugin:@typescript-eslint/recommended",
        "prettier", // Add "prettier" last. This will turn off eslint rules conflicting with prettier. This is not what will format our code.
    ],
    rules: {
        quotes: ["error", "double"],
        semi: ["error", "always"],
        indent: ["error", 4],
    },
};
/*

// npm i -D \
//   @typescript-eslint/parser \
//   @typescript-eslint/eslint-plugin \
//   @typescript-eslint/parser@2.2.0 \
//   @typescript-eslint/eslint-plugin@2.2.0

yarn add -D \
    eslint \
    @typescript-eslint/eslint-plugin \
    prettier eslint-config-prettier
*/
