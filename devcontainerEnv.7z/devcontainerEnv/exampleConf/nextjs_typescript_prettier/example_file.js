var   helloYou    = (name  ) => {
    name    = "you" || name
    console.log("hello" + name + "!")
}
