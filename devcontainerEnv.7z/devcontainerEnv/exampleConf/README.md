```bash
("sandbox" ; "style | esm | react | yes | browser, node | guide | google | JSON")
npx create-next-app --typescript --use-npm && cd sandbox && npm install -D prettier eslint-config-prettier eslint-plugin-prettier @next/eslint-plugin-next && npx eslint --init

(Add .prettierrc)
touch .prettierrc && echo -e "# others\n/dist\nlogs\ntmp" >> .gitignore && cp .gitignore .prettierignore && cp .gitignore .eslintignore

(Update .eslintrc.json :
...
  "extends": [
    //"eslint:recommended",
    "plugin:react/recommended",
    "plugin:@next/next/recommended",
    "google",
    "prettier"
  ],
...
  "rules": {
    "require-jsdoc": "off",
    "react/react-in-jsx-scope": "off"
  },
  "settings": {
    "react": {
      "version": "detect"
    }
  }
...
)

npm run lint

```

git clean -Xdf
